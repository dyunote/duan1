 <!-- BANNER -->
     <section class="banner">
      <img src="banner.jpg" alt="" />
    </section>
     <section class="slider-area">
        <div class="slide-list">
            <div class="slide-item active">
                <img src="img/banner.png" alt="Banner 1" />
            </div>
            
            <div class="slide-item">
                <img src="img/Desktop - 17.png   " alt="Banner 2" />
            </div>
            
            <button class="prev-btn">&#10094;</button>
            <button class="next-btn">&#10095;</button>

            
            <div class="slide-dots">
                <span class="dot active"></span>
                <span class="dot"></span>
            </div>
        </div>
    </section>