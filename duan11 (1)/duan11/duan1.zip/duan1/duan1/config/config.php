<?php
// config/config.php
define('BASE_URL', 'http://localhost/project/'); // sửa theo đường dẫn của bạn
