<?php

class AuthController {
     public function banner() {
        $content = __DIR__ . "/../views/layouts/banner.php";
        include __DIR__ . "/../views/layouts/master.php";
    }
    public function menu() {
        $content = __DIR__ . "/../views/layouts/menu.php";
        include __DIR__ . "/../views/layouts/master.php";
    }
    public function product() {
        $content = __DIR__ . "/../views/layouts/product.php";
        include __DIR__ . "/../views/layouts/master.php";
    }
    public function article() {
        $content = __DIR__ . "/../views/layouts/article.php";
        include __DIR__ . "/../views/layouts/master.php";
    }

    public function login() {
        $content = __DIR__ . "/../views/auth/login.php";
        include __DIR__ . "/../views/layouts/master.php";
    }

    public function register() {
        $content = __DIR__ . "/../views/auth/register.php";
        include __DIR__ . "/../views/layouts/master.php";
    }

    public function forget() {
        $content = __DIR__ . "/../views/auth/forget.php";
        include __DIR__ . "/../views/layouts/master.php";
    }
   
}
