<div class="container-box">

  <div class="category-title">
    <span>PHỤ KIỆN CASAGO</span>
  </div>

  <div class="banner-euromax">
    <img src="img/-2749.jpg" alt="">
  </div>

  <div class="product-wrapper">
    <div class="product-list">

      <div class="product-card"
           data-product_id="1"
           data-category_id="2"
           data-brand_id="3"
           data-name="Bình đun siêu tốc Philips 1.2 lít HD9303"
           data-price="625000"
           data-price_sale="399000"
           data-stock="50"
           data-status="1">

        <div class="product-img">
          <img src="public/img/bepTu.jpg" alt=""
               data-image="public/img/bepTu.jpg">
        </div>

        <h3 class="product-name" data-field="name">
          Bình đun siêu tốc Philips 1.2 lít HD9303
        </h3>

        <div class="product-price">
          <span class="price-new" data-field="price_sale">399.000đ</span>
          <span class="price-old" data-field="price">625.000đ</span>
        </div>

        <div class="product-discount">
          <span class="discount-badge">-36%</span>
        </div>

        <div class="product-note">
          Mua online giảm thêm đến <b>700.000đ</b>
        </div>
      </div>

    </div>
  </div>
</div>
