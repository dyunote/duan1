<link rel="stylesheet" href="public/css/forget.css">

<div class="container">
    <img class="logo" src="public/img/logo1.png" alt="CasaGo" />
    <h1>Quên mật khẩu</h1>
    <p class="desc">Hãy nhập số điện thoại và email để khôi phục mật khẩu.</p>

    <form action="index.php?act=forget_action" method="post">
        <label>Số điện thoại</label>
        <input type="text" name="phone" placeholder="Nhập số điện thoại" />

        <label>Email đăng nhập</label>
        <input type="text" name="email" placeholder="Nhập Email đăng nhập" />

        <div class="btn-row">
            <a href="index.php?act=login">
                <button type="button" class="btn-back">◀ Quay lại đăng nhập</button>
            </a>
            <button class="btn-next">Tiếp tục</button>
        </div>
    </form>
</div>
