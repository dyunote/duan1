<?php

include __DIR__ . "/header.php";
include __DIR__ . "/menu.php";
include __DIR__ . "/banner.php";
include __DIR__ . "/product.php";
include __DIR__ . "/article.php";
include __DIR__ . "/footer.php";








