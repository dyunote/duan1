<?php
require_once "controllers/AuthController.php";

$act = $_GET['act'] ?? 'article'; // mặc định hiện 


$auth = new AuthController();
$layouts = new AuthController();
$menu = new AuthController();
$banner = new AuthController();
$product = new AuthController();

switch ($act) {
    case 'product':
        $product->product();
        break;
    case 'banner':
        $banner->banner();
        break;
    case 'menu':
        $menu->menu();
        break;
    case 'article':
        $layouts->article();
        break;
    case 'login':
        $auth->login();
        break;
    case 'register':
        $auth->register();
        break;
    case 'forget':
        $auth->forget();
        break;
    default:
        include "views/home/index.php";
        break;
}
